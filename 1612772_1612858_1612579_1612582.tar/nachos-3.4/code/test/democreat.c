#include "syscall.h"

void main(){
	int res;
	res = CreateFile("demohhh.txt");
	//printf("%d\n", res);
}
