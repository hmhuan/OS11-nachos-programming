#include "syscall.h"

int main() {
	PrintInt(10);
	return 0;
}
