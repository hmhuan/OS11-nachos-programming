#include "syscall.h"

void main(){
	PrintString("hello my friend");
}