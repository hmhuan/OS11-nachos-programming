#include "syscall.h"
void main() 
{	
	int pingPID, pongPID, i;
	PrintString("\nChuong trinh bat dau ...\n");
	Exec("./test/pong");
	pingPID = Exec("./test/ping");
	pongPID = Exec("./test/pong");
	
	while(1)
	{
	}
}
