#include "syscall.h"

int main() {
	char *s;
	s = "Huynh Trong Thoai - 1512551\nNguyen Anh Tuan - 1512636\nChuong trinh in ra bang ASCII: Xuat ra bang ma ASCII\nChuong trinh sap xep bang thuat toan BubbleSort\n\t+ Buoc 1: Nhap mang\n\t+ Buoc 2: Sap xep\n\t+ Buoc 3: Xuat mang\n";
	PrintString(s);
	Exit(0);
	return 0;
}
