#include "syscall.h"

int main() {
	PrintChar('a');
	return 0;
}
