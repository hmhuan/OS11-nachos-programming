#include "syscall.h"
int main() {
	char c = ReadChar();
	PrintChar(c);
	return 0;
}
