#include "syscall.h"

int main() {
	int n = ReadInt();
	PrintInt(n);
	return 0;
}
